#ifndef LINKED_BTREE_CPP
#define LINKED_BTREE_CPP
#include <iostream>
#include "LinkedBTree.h"

using namespace std;

template<class ItemType>
LinkedBSearchTree<ItemType>::LinkedBSearchTree(): rootPtr(nullptr) {}

template<class ItemType>
int LinkedBSearchTree<ItemType>::getHeight() const
{
  return getHeightHelper(rootPtr);
} 


template<class ItemType>
int LinkedBSearchTree<ItemType>::getHeightHelper(LinkedBTreeNode<ItemType>* subTreePtr) const
{
	if (subTreePtr == nullptr)
	{
    	return 0;
	}
	else
	{
		return 1 + std::max(getHeightHelper(subTreePtr->getLeftChildPtr()), getHeightHelper(subTreePtr->getRightChildPtr()));
	}
} 
template<class ItemType> 
bool LinkedBSearchTree<ItemType>::add(const ItemType& newData)
{ 

  LinkedBTreeNode<ItemType>* newNodePtr = new LinkedBTreeNode<ItemType>(newData);

  rootPtr = placeNode(rootPtr, newNodePtr);

  return true;
}

template<class ItemType>
void LinkedBSearchTree<ItemType>::preorder( LinkedBTreeNode<ItemType>* treePtr) const
{
  if (treePtr != nullptr)
  {
	  	  ItemType item = treePtr->getItem();
	  cout << item << " ";
    preorder(  treePtr->getLeftChildPtr());
    preorder(  treePtr->getRightChildPtr());
  }
} 

template<class ItemType>
void LinkedBSearchTree<ItemType>::inorder( LinkedBTreeNode<ItemType>* treePtr)const
{
	
  if (treePtr != nullptr)
  {
	  ItemType item = treePtr->getItem();
    inorder(  treePtr->getLeftChildPtr());
	 cout << item << " ";
    inorder(  treePtr->getRightChildPtr());
  }
} 

template<class ItemType>
void LinkedBSearchTree<ItemType>::postorder( LinkedBTreeNode<ItemType>* treePtr)const
{

  if (treePtr != nullptr)
  {
	  	  ItemType item = treePtr->getItem();
    postorder(treePtr->getLeftChildPtr());
    postorder(treePtr->getRightChildPtr());
	 cout << item << " ";
  }
} 




template<class ItemType>
LinkedBTreeNode<ItemType>* LinkedBSearchTree<ItemType>::placeNode(LinkedBTreeNode<ItemType>* subTreePtr, LinkedBTreeNode<ItemType>* newNodePtr)
{

	if (subTreePtr == nullptr)
	{
		return newNodePtr;
	}
	else if(subTreePtr->getItem() > newNodePtr->getItem())
	{
		LinkedBTreeNode<ItemType>* tempPtr = placeNode(subTreePtr->getLeftChildPtr(), newNodePtr);
		subTreePtr->setLeftChildPtr(tempPtr);
	}
	else
	{
		LinkedBTreeNode<ItemType>* tempPtr = placeNode(subTreePtr->getRightChildPtr(), newNodePtr);
		subTreePtr->setRightChildPtr(tempPtr);
	} 
	return subTreePtr;
} 

template<class ItemType>
void LinkedBSearchTree<ItemType>::preorderTraverse() const
{
	preorder(rootPtr);
}

template<class ItemType>
void LinkedBSearchTree<ItemType>::inorderTraverse() const
{
	inorder(rootPtr);
}

template<class ItemType>
void LinkedBSearchTree<ItemType>::postorderTraverse() const
{
	postorder(rootPtr);
}
#endif