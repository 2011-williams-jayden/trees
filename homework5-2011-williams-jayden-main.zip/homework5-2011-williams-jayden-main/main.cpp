//Main Driver
//Date: 11/14/21
//Author: Jayden Williams
#include <iostream>
#include <time.h>
#include "LinkedBTreeNode.h"
#include "LinkedBTree.h"
using namespace std;


int main()
{
    LinkedBSearchTree<int> Tree;

    int data[100];

    srand(time(NULL));



    for(int ii = 0; ii < 100; ii++)
    {
        data[ii] = (rand() % 200) + 1;
          Tree.add(data[ii]);
    }
    cout << endl << "PreOrder:" << endl;
    Tree.preorderTraverse();

    cout << endl << "InOrder:" << endl;
    Tree.inorderTraverse();

    cout << endl << "PostOrder:" << endl;
    Tree.postorderTraverse();

    cout << endl << "Height: " << Tree.getHeight() << endl;

}